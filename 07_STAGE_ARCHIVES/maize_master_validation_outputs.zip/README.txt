VALIDATION STAGE
The original /mnt/data/maize_master_data/MASTER_MAIZE_ALL_DATA.csv is unchanged.
MASTER_MAIZE_VALIDATED.csv preserves every row and appends validation/ML eligibility fields.
MASTER_MAIZE_EXACT_DEDUP_CANDIDATE.csv removes only exact duplicate later occurrences.
DUPLICATE_REVIEW.csv contains exact duplicates and semantic conflicts.
GENOTYPE_NAME_MATCH_CANDIDATES.csv contains manual-review candidates for cross-document genotype mapping.
No source values were silently corrected.
The previous broad 'IO' flag was intentionally not carried forward because it also matched valid names such as BIO.
