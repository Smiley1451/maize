MAIZE NORMALIZATION STAGE

The raw validated master is not modified.
GENOTYPE_MASTER.csv creates deterministic identity candidates from source names.
GENOTYPE_ALIASES.csv lists all source-name variants.
TRAIT_MASTER.csv maps source variables to canonical traits where semantics are safe.
TRAIT_ALIASES.csv provides record-level trait mappings.
UNIT_CONVERSION_RULES.csv contains explicit conversions for harmonizable yield/stand units.
STANDARDIZED_OBSERVATIONS.csv is the working layer with candidate genotype IDs, canonical traits and standard values.
NORMALIZATION_REVIEW_QUEUE.csv contains genotype alias groups and ambiguous source-specific traits requiring source review.
No uncertain biological identity was silently merged.
